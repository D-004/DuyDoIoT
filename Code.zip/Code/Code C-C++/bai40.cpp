// Sắp xếp mảng tăng dần, sắp xếp mảng giảm dần
#include"stdio.h"

void thamchieu(int &a, int &b){
    int dem = a;
    a=b;
    b=dem;
}

void sapxeptang(int x[], int n){
    for (int i=0; i<n-1; i++){
        int vitrilonnhat = i;
        for (int j=i+1; j<n; j++){
            if(x[j]<x[vitrilonnhat]){
                vitrilonnhat = j;
            }
        }
        thamchieu(x[i],x[vitrilonnhat]);
    }
}

void sapxepgiam(int x[], int n){
    for (int i=0; i<n-1; i++){
        int vitrinhonhat = i;
        for (int j=i+1; j<n; j++){
            if(x[j]>x[vitrinhonhat]){
                vitrinhonhat = j;
            }
        }
        thamchieu(x[i],x[vitrinhonhat]);
    }
}

void printf(int x[], int n){
    for (int i=0; i<n; i++){
        printf("%d ", x[i]);
    }
}

int main(){
    int a[100];
    int n;
    do{
        printf("Nhap so phan tu cua mang: ");
        scanf("\n%d", &n);
    }while (n<1 || n>100);
    
    for (int i=0; i<n; i++){
        printf("\na[%d] = ", i);
        scanf("%d", &a[i]);
    }

    printf("\nSap xep tang dan: ");
    sapxeptang(a,n);
    printf(a,n);

    printf("\nSap xep giam dan: ");
    sapxepgiam(a,n);
    printf(a,n);

}
