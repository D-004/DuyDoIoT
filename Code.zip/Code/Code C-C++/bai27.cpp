// Hàm trong lập trình C, kiểm tra số nguyên tố
#include<stdio.h>
#include"math.h"

int songuyento(int x){
    if (x<=1)
        return 0;
    for (int i=2; i<=x-1; i++){
        if (x%i==0)
            return 0;
    }
    return 1;
}

int main(){
    int  n;
    printf("Nhap vao n: ");
    scanf("%d", &n);

    int kt = songuyento(n);

    if (kt==0){
        printf("\nKhong phai la so nguyen to.");
    }else{
        printf("\nLa so nguyen to.");
    }
}