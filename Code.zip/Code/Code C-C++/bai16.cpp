// Giải phương trình bậc 2 ax^2 + bx +c = 0
#include<stdio.h>
#include"math.h"

int main(){
    float a,b,c;
    float delta, x1, x2;
    printf("Nhap cac nghiem cua pt ax^2 + bx + c = 0 ");
    printf("\n Nhap so a = ");
    scanf("%f", &a);
    printf("\n Nhap so b = ");
    scanf("%f", &b);
    printf("\n Nhap so c = ");
    scanf("%f", &c);
    delta = (b*b) - (4*a*c);
    if (delta > 0){
        printf("\nPhuong trinh co 2 nghiem phan biet");
        x1 = (-b + sqrt(delta))/(2*a);
        x2 = (-b - sqrt(delta))/(2*a);
    }else if (delta == 0){
        printf("\nPhuong trinh co nghiem kep");
        x1 = x2 = -b/(2*a);
    }else{
        printf("\nPhuong trinh vo nghiem");
    }
}