// Tìm kiếm trong mảng 1 chiều 
#include"stdio.h"

int a[100];
int n;

void  nhapMang(int x[100], int  &n){
    printf(" Nhap so luong phan tu: ");
    scanf("%d", &n);
    for (int i=0; i<n ; i++){
        printf("x[%d] = ", i);
        scanf("%d", &x[i]);
    }
}

void xuatMang(int x[100], int n){
    pnritf("\nMang vua nhap: ");
    for (int i=0; i<n; i++){
        printf("%d ", x[i]);
    }
}

int Timkiem(int x[100], int n, int tk){
    int kq = 0;
    for (int i=0; i<n ; i++){
        if (tk == x[i] ){
            kq = 1;
            return 1;
        }
    }
    return kq;
}

void Timkiemkq(int x[100], int n){
    int tk;
    printf("\nNhap so can tim: ");
    scanf("%d", &tk);
    int kq = Timkiem(x,n,tk);
    if (kq == 1){
        printf("\nTim thay");
    }else{
        printf("\nKhong tim thay");
    }
}

void prin(int x[100], int tk){
    printf("\nNhap so can dem: ");
    scanf("%d", &tk);
}

int Dem(int x[100], int tk){
    prin(a,n);
    int dem = 0;
    for (int i=0; i<n ; i++){
        if (tk == x[i] ){
            dem += 1;
        }
    }
    return dem;
}

void Vitri(int x[100], int n, int tk){
    printf("\nVi tri cua so can tim la: ");
    for (int i=0; i<n ; i++){
        if (tk == x[i] ){
        printf("%d ", i);
        }
    }
}

int main(){
    int tk;
    nhapMang(a, n);
    xuatMang(a, n);
    Timkiemkq(a, n);
    int Demkq = Dem(a,n);
    printf("\nSo lan xuat hien trong mang la: %d", Demkq);
    Vitri(a,n,tk);
}