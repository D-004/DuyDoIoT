// Vòng lặp Do - While
#include"stdio.h"

int main(){
    int a;
    do{
        printf("------------");
        printf("\n----MENU----");
        printf("\n-------------");
        printf("\nNhap vao so 0 de thoat");
        printf("\nNhap vao so khac 0 de tiep tuc\n");
        scanf("%d", &a);
    }while (a!=0);
}