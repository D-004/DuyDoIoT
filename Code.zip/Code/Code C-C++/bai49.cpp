// Kiểm tra mảng B có phải là mảng con của mảng A hay không
#include"stdio.h"
#include"limits.h"
#include"stdlib.h"

void NhapMang(int x[100], int &n){
    printf("Nhap so luong phan tu trong mang: ");
    scanf("%d", &n);
    for (int i=0; i<n; i++){
        printf("\nx[%d]= ", i);
        scanf("%d", &x[i]);
    }
}

void XuatMang(int x[100], int n){
    printf("\nMang vua nhap la: ");
    for (int i =0; i<n; i++){
        printf("%d ", x[i]);
    }
}

void Sapxep(int x[100], int n){
    printf("\nMang sap xep: ");
    for (int i=0; i<n-1; i++){
        for (int j=i+1; j<n; j++){
            if (x[i]>x[j]){
                int temp = x[i];
                x[i] = x[j];
                x[j] = temp;
            }
        }
    }
}

int MangCon(int x1[100], int n1, int x2[100], int n2){
    int kq =  0;
    if (n1>=n2){
        for (int i=0; i<n1; i++){
            if (x1[i]==x2[0]){
                int j;
                for (j=0; j<n2; j++){
                    if (x1[i+j] != x2[j])
                        break;
                }
                if (j==n2)
                    kq = 1;
            }
        }
    }return kq;
}

int main(){
    int n1, n2;
    int a[100], b[100];

    NhapMang(a,n1);
    XuatMang(a,n1);
    printf("\n--------\n");
    NhapMang(b,n2);
    XuatMang(b,n2);
    Sapxep(a,n1);
    XuatMang(a,n1);
    int kq = MangCon(a,n1,b,n2);
    if (kq == 1){
        printf("\nMang b la mang con cua a");
    }else {
        printf("\nMang b khong phai la mang con cua a");
    }
}