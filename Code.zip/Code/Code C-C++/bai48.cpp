// Tách mảng 1 chiều thành 2 mảng
#include"stdio.h"
#include"conio.h"
#include"stdlib.h"

void nhapMang(int x[100], int &n){
	printf("Nhap so phan tu cua mang: ");
	scanf("%d", &n);
	for (int i=0; i<n; i++){
		printf("\nx[%d] = ", i);
		scanf("%d", &x[i]);
	}
}

void xuatMang(int x[100], int n){
	printf("\nMang vua nhap: ");
	for (int i=0; i<n; i++){
		printf("%d ", x[i]);
	}
}

void sapxep(int x[100], int n){
	for (int i=0; i<n-1; i++){
		for (int j=i+1; j<n; j++){
			if (x[i]>x[j]){
				int temp = x[i];
				x[i] = x[j];
				x[j] = temp;
			}
		}
	}
}

void taoMang(int x[100], int n, int x1[100], int &n_1, int x2[100], int &n_2){
	int i1 = 0;
	int i2 = 0;
	n_1 = 0;
	n_2 = 0;
	for (int i=0; i<n; i++){
		if (x[i]%2==0){
			x1[i1] = x[i];
			i1++;
			n_1++;
		}else {
			x2[i2] = x[i];
			i2++;
			n_2++;
		}
	}
}

int main(){
	int n, n1, n2;
	int a[100], b[100], c[100];
	nhapMang(a,n);
	xuatMang(a,n);
	sapxep(a,n);
	printf("\n--------");
	taoMang(a, n, b, n1, c, n2);
	xuatMang(b, n1);
	printf("\n--------");
	xuatMang(c, n2);
	printf("\n--------");
}