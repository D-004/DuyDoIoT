// Đảo ngược mảng 1 chiều
#include"stdio.h"

int a[100];
int n;

void nhapMang(int x[100], int &n){
    printf("Nhap so luong phan tu: ");
    scanf("%d", &n);
    for (int i=0; i<n; i++){
        printf("x[%d]= ", i);
        scanf("%d", &x[i]);
    }
}

void xuatMang(int x[100], int n){
    for (int i=0; i<n; i++){
        printf("%d ", x[i]);
    }
}

void xuatMangvuanhap(int x[100], int n){
    printf("\nMang vua nhap: ");
    for (int i=0; i<n; i++){
        printf("%d ", x[i]);
    }
}

void DaoNguoc(int x[100], int n){
    printf("\nMang dao nguoc la: ");
    for (int i=n-1; i>=0; i--){
        printf("%d ", x[i]);
    }
}

void mangDaoNguoc(int x[100], int n){
    printf("\nMang dao nguoc: " );
    for (int i=0; i<=n/2; i++){
        int temp = x[i];
        x[i] = x[n-i-1];
        x[n-i-1] = temp;
    }
}

int main(){
    nhapMang(a,n);
    xuatMangvuanhap(a,n);
    DaoNguoc(a,n);
    printf("\n");
    mangDaoNguoc(a,n);
    xuatMang(a,n);
}