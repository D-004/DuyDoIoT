#include<stdio.h>

int main(){
    printf("Bai 003 - Xuat du lieu ra man hinh");
    int x = 5;
    printf("\n Gia tri cua x la: %d", x);
    float x1 = 3.141556;
    printf("\n Gia tri cua x1 la: %f", x1);
    printf("\n Gia tri cua x1 la: %.2f", x1);
    float x2 = 5.6;
    float x3 = 2.7;
    printf("\n x2 = %.2f , x3 = %.2f ", x2,x3);
    char y = 'A';
    printf("\n y = %c", y);
}