// Phần 1: Đính kèm các thư viện
#include<stdio.h>
// Phần 2: Phần khai báo biến, hằng

// Phần 3: Các hàm, phương thức 
/**/ 
int main(){
    printf("Xin chao, toi la Do");
}
