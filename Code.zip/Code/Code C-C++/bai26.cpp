// Lệnh goto và lệnh continue
#include"stdio.h"

int main(){
   int n,i;
   Nhay:
        printf("Nhap vao so n: ");
        scanf("%d", &n);
   if(n<=0) goto Nhay; 

   for (i=1; i<=n; i++){
        if(i%2==0) continue;
        printf("\n%d",i);
   }
}