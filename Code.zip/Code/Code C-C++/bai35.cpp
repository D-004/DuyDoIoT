// Mảng một chiều
#include"stdio.h"

int main(){
    // Khai báo mảng
    int n[10];
    float b[100];
    char c[1000];

    // Khai báo mảng và gắn giá trị ban đầu
    int x[10] = {};
    int y[3] = {9, 6, 15};
    
    // Gán dữ liệu cho mảng
    // Mảng bắt đầu từ vị trí số 0
    y[1] = 10;

    printf("\n0 - %d", y[0]);
    printf("\n1 - %d", y[1]);
    printf("\n2 - %d", y[2]);
}