// Các toán tử so sánh
#include<stdio.h>

int main(){
    int a, b;
    printf("Nhap vao so a: ");
    scanf("%d", &a);
    printf("\nNhap vao so b: ");
    scanf("%d", &b);

    printf("\n %d == %d la %d", a,b,a==b);
    printf("\n %d >= %d la %d", a,b,a>=b );
    printf("\n %d != %d la %d", a,b, a!=b);
}