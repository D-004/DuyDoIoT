#include"stdio.h"
#include"limits.h"

void NhapMang(int x[100], int &n){
    printf("\nNhap so luong phan tu cua mang: ");
    scanf("%d", &n);
    for (int i=0; i<n; i++){
        printf("\nx[%d]= ", i);
        scanf("%d", &x[i]);
    }
}

void XuatMang(int x[100], int n){
    printf("\nMang vua nhap: ");
    for (int i=0; i<n; i++){
        printf("%d ", x[i]);
    }
}

void xoaMang(int x[100], int &n, int vitri){
    for (int i = vitri; i < n-1; i++){
        if (vitri == x[i]){
            x[vitri]=x[n+1];
        }
    }
    n--;
}

void xoaSotrongmang(int x[100], int &n){
    int gt;
    printf("\nNhap vao so can xoa: ");
    scanf("%d", &gt);
    for (int i=0; i<n; i++){
        if (gt == x[i]){
            xoaMang(x,n,i);
        }
    }
}

int main(){
    int a[100];
    int n;

    NhapMang(a,n);
    XuatMang(a,n);
    printf("\n");
    xoaSotrongmang(a,n);
    printf("\n");
    XuatMang(a,n);
}