// Câu lệnh điều kiện - Câu lệnh if-else
#include<stdio.h>
#include"math.h"

int main(){
    // Nhập số n, Kiểm tra n là số Chẵn hay lẻ
    int n;
    printf("Nhap so n : ");
    scanf("%d", &n);
    if (n%2==0){
        printf("\n So vua nhap la so Chan");
    }else{
        printf("\n So vua nhap la so Le");
    }
}