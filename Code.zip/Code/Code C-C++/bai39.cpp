// Tìm max, min, giá trị lớn nhất, giá trị nhỏ nhất
#include<stdio.h>

int timMIN(int x[], int n){
    int min = x[0];
    for (int i=1; i<n; i++){
        if (min>x[i]){
            min =x[i];
        }
    }return min;
}

int timMAX(int x[], int n){
    int max = x[0];
    for (int i=1; i<n; i++){
        if (max<x[i]){
            max =x[i];
        }
    }return max;
}

int main(){
    int a[100];
    int n;
    do{
        printf("Nhap so phan tu cua mang: ");
        scanf("\n%d", &n);
    }while (n<1 || n>100);
    
    for (int i=0; i<n; i++){
        printf("\na[%d] = ", i);
        scanf("%d", &a[i]);
    }

    printf("\nMIN la: %d",timMIN(a,n));
    printf("\nMAX la: %d",timMAX(a,n));
}
