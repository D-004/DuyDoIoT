// Nhập xuất mảng một chiều, tính tổng các phần tử mảng một chiều
#include"stdio.h"

int main(){
    int a[100];
    int n;
    do {
       printf("Nhap mang so phan tu co trong mang n: ");
       scanf("%d", &n); 
    }while (n<0 || n>=100);

    for (int i=0; i<n; i++){
        printf("\na[%d] = ", i);
        scanf("%d", &a[i]);
    }
    
    printf("\nMang vua nhap la: ");
    for (int i=0; i<n; i++){
        printf("%d ", a[i] );
    }

    int tong = 0;
    for (int i=0; i<n; i++){
        tong += a[i];
    }
    printf("\nTong cua mang: %d", tong);
}