// Chèn phần tử vao mảng 1 chiều
#include"stdio.h"
#include"limits.h"

void nhapMang(int x[100], int &n){
    do {
    printf("Nhap so luong phan tu trong mang: ");
    scanf("%d",&n);
    }while(n<1);
    for (int i = 0; i<n; i++){
        printf("\nx[%d]= ", i);
        scanf("%d", &x[i]);
    }
}

void xuatMang(int x[100], int n){
    printf("\nMang vua nhap: ");
    for (int i=0; i<n; i++){
        printf("%d ", x[i]);
    }
}

void themvaocuoi(int x[100], int &n, int m){
    int size = sizeof(x)/sizeof(x[0]);
    if (n==size){
        printf("\nKhong the them vao mang: ");
    }
    x[n]=m;
    n++;
}

void themvaodau(int x[100], int &n, int m){
    int size = sizeof(x)/sizeof(x[0]);
    if (n==size){
        printf("\nKhong the them vao mang: ");
    }
    n++;
    for (int i=1; i<n; i++){
        x[i]=x[i-1];
    }
    x[0]=m;
}

void themvaovitri(int x[100], int &n, int m, int vitri){
    int size = sizeof(x)/sizeof(x[0]);
    if (n==size){
        printf("\nKhong the them vao mang: ");
    }
    n++;
    for (int i=n-1; i<vitri; i--){
        x[i]=x[i-1];
    }
    x[vitri]=m;
}

int main(){
    int a[100];
    int n;
    nhapMang(a,n);
    xuatMang(a,n);
    printf("\n");
    themvaodau(a,n, 11);
    nhapMang(a,n);
    printf("\n");
    themvaocuoi(a,n, 11);
    nhapMang(a,n);
    printf("\n");
    themvaovitri(a,n,11, 4);
    nhapMang(a,n);
}