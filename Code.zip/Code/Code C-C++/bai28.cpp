// Xuất ra tất cả các số nguyên tố nhỏ hơn bằng n
#include"stdio.h"
#include"math.h"

int kiemtra(int x){
    if (x<=1)
        return 0;
    for (int i=2; i<=sqrt(x); i++){
        if (x%i==0) return 0;
    }
    return 1; 
}

int main(){
    int n;
    do {
    printf("Nhap so n: ");
    scanf("%d", &n);
    }while (n<1);
    for (int j =2; j<=n; j++){
        if (kiemtra(j)){
            printf("\n%d", j);
        }
    }
}
