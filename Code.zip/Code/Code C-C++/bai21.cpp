// Bảng mã ASCII và bảng mã Alphabet
#include "stdio.h"
int main(){
    char kytu;
    for (kytu=65; kytu<=90; kytu++){
        printf("%d - %c\n", kytu, kytu);
    }
}