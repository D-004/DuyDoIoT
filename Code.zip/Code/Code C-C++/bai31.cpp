// Truyền tham chiếu và truyền tham trị
#include"stdio.h"

void truyenthamtri(int a, int b){
    int ham = a;
    a=b;
    b=ham;
}

void truyenthamchieu(int &a, int &b){
    int ham = a;
    a=b;
    b=ham;
}

int main(){
    int a, b;
    printf("Nhap vao 2 so a, b: ");
    scanf("%d%d", &a, &b);

    printf("\nGia tri ban dau: a = %d, b = %d", a, b);
    truyenthamtri(a,b);
    printf("\nHoan doi - Truyen tham tri: a = %d, b = %d", a,b);
    truyenthamchieu(a,b);
    printf("\nHoan doi - Truyen tham chieu: a = %d, b = %d", a,b);
}