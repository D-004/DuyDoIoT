// Giải pt bậc nhất ax + b = 0
#include<stdio.h>

int main(){
    float a,b,x;
    printf("Nhap vao so a: ");
    scanf("%f", &a);
    printf("\n Nhap vao so b: ");
    scanf("%f", &b);
    if(a != 0){
        x = -b/a;
        printf("\n Phuong trinh co nghiem duy nhat: x = %f", x);
    }else if (a==0 && b!=0){
        printf("\n Phuong trinh vo nghiem");
    }else{
        printf("\n Phuong trinh co vo so nghiem");
    }
}