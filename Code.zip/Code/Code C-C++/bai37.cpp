// Truyền tham số mảng, tính trung bình cộng mảng
#include"stdio.h"

float trungbinhcong(int x[], int a){
    int Tong = 0;
    for (int i=0; i<a; i++){
        Tong += x[i];
    }
    return (float)Tong/a;
}

float Tbccacsoduong(int x[], int a){
    int Tong = 0;
    int Cacsoduong = 0;
    for (int i=0; i<a; i++){
        if (x[i]>=0){
            Tong += x[i];
            Cacsoduong++;
        }
    }return Cacsoduong>0?(float)Tong/Cacsoduong:-1;
}

int main(){
    int a[100];
    int n;
    do{
        printf("Nhap so phan tu cua mang: ");
        scanf("\n%d", &n);
    }while (n<1 || n>100);

    for (int i=0; i<n; i++){
        printf("\na[%d] = ", i);
        scanf("%d", &a[i]);
    }

    printf("\nTrung binh cong cac phan tu trong mang la: %.2f", trungbinhcong(a,n));

    printf("\nTrung binh cong cac so duong la: %.2f", Tbccacsoduong(a, n));
}