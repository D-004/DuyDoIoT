// Các hàm toán học 
#include<stdio.h>
#include"math.h"

int main(){
    int a =15;
    int b =2;
    float kq = (float)a/b;

    printf("floor(a/b) =  %f",floor(kq) );
    printf("\n ceil(a/b) = %f", ceil(kq));
    printf("\n sqrt(9)=%.2f", sqrt(9));
    printf("\n 5^2 = %f", pow(5,2));
    printf("\n |5.2| = %f", abs(5.2));
}