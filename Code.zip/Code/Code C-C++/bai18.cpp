// Bài tập tìm số ngày của tháng
#include<stdio.h>

int main(){
    int thang, nam;
    printf("Nhap thang - nam :");
    printf("\nNhap thang: ");
    scanf("%d", &thang);
    printf("\nNhap nam: ");
    scanf("%d", &nam);

    switch (thang){
        case 1:
        case 3:
        case 5:
        case 7:
        case 8:
        case 10:
        case 12:
                printf("\nThang co 31 ngay");
                break;
        case 4:
        case 6:
        case 9:
        case 11:
                printf("\nThang co 30 ngay");
                break;
        case 2:
                if ((nam%4)==0 && (nam%100)!=0){
                    printf("\nThang 2 co 29 ngay");
                }else{
                    printf("\nThang 2 co 28 ngay");
                }
                break;
        default:
                printf("\nThang nhap khong hop le ");
                break;
    }   
    
}