// Thuật toán liệt kê các phần tử thỏa mãn điều kiện liệt kê các số nguyên tố
#include<stdio.h>

int lietke(int x){
    return (x%2==0 && x%3==0);
}

int main(){
    int a[100];
    int n;
    do{
        printf("Nhap so phan tu cua mang: ");
        scanf("\n%d", &n);
    }while (n<1 || n>100);
    
    for (int i=0; i<n; i++){
        printf("\na[%d] = ", i);
        scanf("%d", &a[i]);
    }
    printf("\nCac so chia het cho 3 va la so chan: ");
    for (int i=0; i<n; i++){
        if (lietke(a[i])){
            printf("%d", a[i]);
        }
    }
}