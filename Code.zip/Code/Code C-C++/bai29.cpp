// Xuất ra tất cả các số chính phương nhỏ hơn bằng n
#include"stdio.h"
#include"math.h"

int kiemtrasochinhphuong(int x){
    int kc = (int)sqrt(x);
    if (pow(kc,2)==x)
        return 1;
    else 
        return 0;
}

int main(){
    int n;
    do {
    printf("Nhap so n: ");
    scanf("%d", &n);
    }while (n<1);
    for (int j =2; j<=n; j++){
        if (kiemtrasochinhphuong(j)){
            printf("\n%d", j);
        }
    }
}
