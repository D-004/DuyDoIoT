// Lập trình đệ quy, tính giai thừa bằng đệ quy
#include"stdio.h"

int giaithua(int  n){
    if (n == 0 || n == 1){
        return 1;
    }else {
        return n*giaithua(n-1);
    }
}

int main(){
    int n, kq;
    do {
        printf("Nhap vao so n: ");
        scanf("%d", &n);
    }while(n<1);

    kq = giaithua(n);
    printf("%d! = %d", n, giaithua);

}