// Ước chung lớn nhất giữa 2 số
#include"stdio.h"
int main(){
    int a, b, UCLN;
    printf("Nhap vao so a: ");
    scanf("%d", &a);
    printf("\nNhap vao so b: ");
    scanf("%d", &b);

    if (a==0 || b==0){
        UCLN = a+b;
        printf("\nUCLN la: %d", UCLN);
    }else{
        while (a!=b){
            if (a>b){
                UCLN = a-b;
                printf("\nUCLN la: %d", UCLN);
                break;
            }else {
                UCLN = b-a;
                printf("\nUCLN la: %d",UCLN);
                break;
            }
        }
    }
}
