// Toán tử điều kiện 
#include<stdio.h>

int main(){
    int a;
    printf("Nhap vao so a: ");
    scanf("%d", &a);
    printf("\n %d la so %s", a, (a%2==1)?"LE":"CHAN");
}