#include "stdio.h"

int main(){
    unsigned long tuoi;
    int so_tien;
    int so_tien_hien_co = 0;
    char a = 'A';
    long dan_so = 3000000000;
    double dien_tich;
    float dien_tich_tam_giac;
    float x,y,z;
}
