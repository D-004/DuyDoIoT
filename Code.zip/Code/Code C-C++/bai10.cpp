// Giải pt ax + b = 0
#include<stdio.h>

int main(){
    // Khai báo biến
    float a, b , x;
    // Nhập dữ liệu
    printf(" Nhap cac thong so de tinh pt ax + b =0");
    printf("\n Nhap so a: ");
    scanf("%f", &a);
    printf("\n Nhap so b: ");
    scanf("%f", &b);
    // Xử lý ctr
    x = -b/a;
    // Xuất
    printf("\n Nghiem pt la x = %.2f", x);
}