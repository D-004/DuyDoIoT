#include<stdio.h>

int main(){
    float a, b;
    printf("Nhap a= ");
    scanf("%f",&a);

    printf("\nNhap b= ");
    scanf("%f", &b);

    float tong = a+b;
    printf("\nTong la: %.2f + %.2f = %.2f",a,b, tong );

    return 0;
}