// Phép ++ và --
#include<stdio.h>

int main(){
    int a = 5, b= 5;
    printf("%d", a++);
    printf("\n");
    printf("%d", a);
    printf("\n");
    printf("%d", ++a);

}