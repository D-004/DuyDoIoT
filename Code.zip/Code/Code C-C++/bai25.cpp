// Giai thừa của số nguyên n
#include"stdio.h"

int main(){
    int a, giaithua, i;

    do{
        printf("Nhap so giai thua a: ");
        scanf("%d", &a);
    }while(a<0);

    giaithua = 1; // Giai thua cua 0 bang 1

    for(i =1; i<=a; i++){
        giaithua = giaithua*i;
    }
    printf("\nGiai thua cua so a la: %d", giaithua);

}