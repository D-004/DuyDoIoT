// Bài tập tính diện tích chu vi và tam giác
#include<stdio.h>
#include"math.h"

int main(){
    // Khai báo biến
    float xa,xb,xc,ya,yb,yc;
    float AB, BC, CA;
    float chuvi, dientich, p;
    // Nhập dữ liệu 
    printf("Nhap toa do dinh A: ");
    scanf("%f%f", &xa, &ya);
    printf("\nNhap toa do dinh B: ");
    scanf("%f%f", &xb, &yb);
    printf("\nNhap toa do dinh C: ");
    scanf("%f%f", &xc, &yc);
    // Tính các cạnh 
    AB = sqrt(pow(xa-xb,2)+pow(ya-yb,2));
    BC = sqrt(pow(xb-xc,2)+pow(yb-yc,2));
    CA = sqrt(pow(xc-xa,2)+pow(yc-ya,2));
    // Kiểm tra có phải là tam giac hay không
    if (AB+BC>CA && AB+CA>BC && BC+CA>AB){
        printf("\nCac canh A, B, C tao thanh duoc tam giac");
        // Kiểm tra có phải tam giác cân hay không
        if (AB == BC || AB == CA || BC == CA){
            printf("\nTam giac ABC la tam giac can");
        }else{
            printf("\nTam giac ABC khong la tam giac can");
        }
        // Tính chu vi
        chuvi = AB+BC+CA;
        printf("\nChu vi tam giac ABC la: %.2f", chuvi);
        p = chuvi/2;
        // Tính diện tích
        dientich = sqrt(p*(p-AB)*(p-BC)*(p-CA));
        printf("\nDien tich tam giac ABC la: %.2f", dientich);
    }else{
        printf("\nCac canh A, B, C khong tao thanh duoc tam giac");
    }
}