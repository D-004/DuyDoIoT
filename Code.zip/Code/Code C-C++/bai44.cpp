// Xóa phần tử theo điều kiện trong mảng 1 chiều 
#include"stdio.h"

void nhapMang(int x[100], int &n ){
    printf("Nhap so phan tu co trong mang: ");
    scanf("%d", &n);
    for (int i=0; i<n; i++){
        printf("\nx[%d]= ", i);
        scanf("%d", &x[i]);
    }
}

void xuatMang(int x[100], int n){
    printf("\nMang vua nhap: ");
    for (int i=0; i<n; i++){
        printf("%d ", x[i]);
    }
}

void xoaMang(int x[100], int &n, int vitri){
    for (int i = vitri; i < n-1; i++){
        if (vitri == x[i]){
            x[vitri]=x[n+1];
        }
    }
    n--;
}

void xoaSotrongmang(int x[100], int &n){
    int gt;
    printf("\nNhap vao so can xoa: ");
    scanf("%d", &gt);
    for (int i=0; i<n; i++){
        if (gt == x[i]){
            xoaMang(x,n,i);
        }
    }
}

int main(){
    int a[100];
    int n;

    nhapMang(a,n);
    xuatMang(a,n);
    printf("\n");
    xoaSotrongmang(a,n);
    printf("\n");
    xuatMang(a,n);
}