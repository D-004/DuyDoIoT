// Vòng lặp for
#include<stdio.h>
 int main(){
    int n, i;
    printf("Nhap n: ");
    scanf("%d", &n);

    for(i =0;i<=n;i--){
        printf("\n%d",i);
        if (i == -50){
            break;
        }
    }
 }