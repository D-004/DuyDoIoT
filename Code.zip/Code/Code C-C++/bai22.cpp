// Vòng lặp While
#include"stdio.h"

int main(){
    int n;
    int tong;
    printf("Nhap so n: ");
    scanf("%d", &n);

    int i = 0;
    while (i<=n){
        tong = tong + i;
        i++;
    }
    printf("\nTong cua n chu so la: %d", tong);
}