// MAX, MIN của 2 số a và b
#include<stdio.h>

int main(){
    // Khai báo biến
    int a, b, min, max;
    // Nhập dữ liệu
    printf(" Nhap vao a: ");
    scanf("%d", &a);
    printf("\n Nhap vao b: ");
    scanf("%d", &b);
    // Xử lý
    min = (a>b)?b:a;
    max = (a>b)?a:b;
    // Xuất dữ liệu
    printf("\n MIN = %d", min);
    printf("\n MAX = %d", max );
}