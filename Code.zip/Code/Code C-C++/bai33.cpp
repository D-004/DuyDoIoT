// Chuyển đổi từ hệ thập phân sang hệ nhị phân trong C
#include "stdio.h"

void henhiphan(int x){
    if (x == 0){
        return;
    }else {
        int r = x%2;
        henhiphan(x/2);
        printf("%d",r);
    }
}

int main(){
    int n;
    do {
        printf("Nhap so n: ");
        scanf("%d", &n);  
    }while (n<0);
    henhiphan(n);
}