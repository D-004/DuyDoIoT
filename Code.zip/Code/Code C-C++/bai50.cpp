// Kiểm tra mảng con liên tiếp giữa 2 mảng
#include"stdio.h"

void Nhapmang(int x[100], int &n){
    printf("\nNhap so phan tu cua mang: ");
    scanf("%d", &n);
    for (int i=0; i<n; i++){
        printf("\nx[%d]= ", i);
        scanf("%d", &x[i]);
    }
}

void Xuatmang(int x[100], int n){
    printf("\nMang vua nhap: ");
    for (int i=0; i<n; i++){
        printf("%d ", x[i]);
    }
}

void Sapxep(int x[100], int n){
    for (int i=0; i<n-1; i++){
        for(int j=i+1; j<n; j++){
            if (x[i]>x[j]){
                int temp = x[i];
                x[i] = x[j];
                x[j] = temp;
            }
        }
    }
}

int timMax(int x[100], int n){
    int max = x[0];
    for (int i=0; i<n; i++){
        if(max<x[i]){
            max = x[i];
        }
    }return max;
}

void mangconlientiep(int x[100], int n){
    int b[100];
    for (int i=0; i<n; i++){
        b[i]=1;
    }
    for (int i=n-1; i>0; i--){
        if (x[i]>=x[i-1]){
            b[i-1] = b[i] + 1;
        }
        printf("\nMang b: ");
        Xuatmang(b, n);
    }
    

    int soLuong = timMax(b, n);
    for (int i=0; i<n; i++){
        if (b[i]==soLuong){
            printf("\nMang khong giam dai nhat: ");
            for (int j=i; j<soLuong; j++)
                printf("%d ", x[j]);
        }
    }
}

int main(){
    int a[100];
    int n;

    Nhapmang(a,n);
    Xuatmang(a,n);
    Sapxep(a,n);
    Xuatmang(a,n);
    mangconlientiep(a, n);
}