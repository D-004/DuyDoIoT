// Tạo menu cho chương trình
// Tìm phần tử nhỏ thứ 2, lớn thứ 2 trong mảng
#include"stdio.h"
#include"limits.h"

void nhapMang(int x[100], int &n){
    printf("Nhap so phan tu cua mang: ");
    scanf("%d", &n);
    for (int i =0;  i<n; i++){
        printf("\nx[%d]= ", i);
        scanf("%d", &x[i]);
    }
}

void xuatMang(int x[100], int n){
    printf("\nCac phan tu trong mang: ");
    for (int i=0; i<n; i++){
        printf("%d ", x[i]);
    }
}

// Tìm MIN thứ 2
int Min2(int x[100], int n){
    int min = INT_MAX;
    int min2 = INT_MAX;
    // Tìm MIN nhỏ nhất
    for (int i =0; i<n; i++){
        if (min > x[i]){
            min = x[i];
        }
    }
    // Tìm MIN nhỏ thứ 2
    for (int i=0; i<n; i++){
        if (min == x[i]){
            continue;
            // Nếu bằng MIN nhỏ nhất thì bỏ qua lệnh và tiếp tục
        }else {
            if (min2>x[i]){
                min2 = x[i];
                // Tìm như MIN nhỏ nhất
            }
        }
    }
    return min2;
}

// Tìm MAX thứ 2 
int Max2(int x[100], int n){
    int max = INT_MIN;
    int max2 = INT_MIN;
    for (int i=0; i<n; i++){
        if (max < x[i]){
            max = x[i];
        }
    }
    for (int i=0; i<n; i++){
        if (max == x[i]){
            continue;
        }else {
            if (max2 < x[i]){
                max2 = x[i];
            }
        }
    }
    return max2;
}


int main(){
    int a[100];
    int n;
    char gt;
    do {
        printf("\n----MENU----");
        printf("\n1 - Nhap mang\n");
        printf("2 - Xuat mang\n");
        printf("3 - Tim MIN thu 2\n");
        printf("4 - Tim MAX thu 2\n");
        printf("x - Thoat\n");
        printf("Lua chon cua ban la: ");
        scanf(" %c", &gt);

        if (gt == '1'){
            nhapMang(a,n);
        }else if (gt == '2'){
            xuatMang(a,n);
        }else if (gt == '3'){
            int x = Min2(a,n);
            printf("\nPhan tu nho thu 2: %d", x);
            printf("\n---------------");
        }else if (gt == '4'){
            int y =  Max2(a,n);
            printf("\nPhan tu lon thu 2: %d", y);
            printf("\n---------------");
        }
    } while (gt!='x');
}